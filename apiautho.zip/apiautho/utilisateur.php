<?php

    class users{
   
        // Connection
        private $conn;

        // Table
        private $db_table = "users";
       
        // Columns
        public $id;
        public $name;
        public $email;
        public $password;
      
        public $token;
       

        // Db connection
        public function __construct($db){
            $this->conn = $db;
        }

        // GET ALL
        public function getusers(){
            $sqlQuery = "SELECT id, name, login, password, token  FROM " . $this->db_table . "";
            $stmt = $this->conn->prepare($sqlQuery);
            $stmt->execute();
            return $stmt;
        }

        // CREATE
        public function createusers(){
            $sqlQuery = "INSERT INTO
                        ". $this->db_table ."
                    SET
                        name = :name, 
                        email = :email, 
                        password = :password, 
                       token= :token";
                     
        
            $stmt = $this->conn->prepare($sqlQuery);
        
            
        
           
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // READ single
        public function getSingleusers(){
            $sqlQuery = "SELECT
                        id, 
                        name, 
                        email, 
                       paasword, 
                        token
                        
                      FROM
                        ". $this->db_table ."
                    WHERE 
                       id = ?
                    LIMIT 0,1";

            $stmt = $this->conn->prepare($sqlQuery);

            $stmt->bindParam(1, $this->id);

            $stmt->execute();

            $dataRow = $stmt->fetch(PDO::FETCH_ASSOC);
            
            $this->name = $dataRow['name'];
            $this->login = $dataRow['login'];
            $this->password = $dataRow['password'];
            $this->token = $dataRow['token'];
         
        }        

        // UPDATE
        public function updateusers(){
            $sqlQuery = "UPDATE
                        ". $this->db_table ."
                    SET
                        name = :name, 
                        email = :email, 
                        password= :password, 
                       token = :token 
                       
                    WHERE 
                        id = :id";
        
            
        
            // bind data
            
        
            if($stmt->execute()){
               return true;
            }
            return false;
        }

        // DELETE
        function deleteusers(){
            $sqlQuery = "DELETE FROM " . $this->db_table . " WHERE id = ?";
            $stmt = $this->conn->prepare($sqlQuery);
        
            $this->id=htmlspecialchars(strip_tags($this->id));
        
            $stmt->bindParam(1, $this->id);
        
            if($stmt->execute()){
                return true;
            }
            return false;
        }

    }
     
    
   
        ?>
