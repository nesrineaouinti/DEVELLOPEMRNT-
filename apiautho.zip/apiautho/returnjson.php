<?php


    header("Access-Control-Allow-Origin: *");
    header("Content-Type: application/json; charset=UTF-8");
    
    include_once 'connectdb.php';
    include_once 'utilisateur.php';

    $database = new Database();
    $db = $database->getConnection();

    $items = new users($db);

    $stmt = $items->getusers();
      
    $itemCount = $stmt->rowCount();


    echo json_encode($itemCount);

    if($itemCount > 0){
       
        $usersArr = array();
        $usersArr["body"] = array();
        $usersArr["itemCount"] = $itemCount;
        
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)){
            extract($row);
            $e = array(
                "id" => $id,
                "name" => $name,
                "login" => $login,
                "password" => $password,
                
                "token" =>$token
                       
               
            );

            array_push($usersArr["body"], $e);
        }
        echo json_encode($usersArr);
    }

    else{
        http_response_code(404);
        echo json_encode(
            array("message" => "No record found.")
        );
    }
   
    
                

?>