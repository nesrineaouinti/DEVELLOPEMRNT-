 <html>
     <body>
     <table style="background-color:antiquewhite" border="0" cellpadding="20" cellspacing="1" width="80%">
     <tr style="background-color:salmon;height:40px">
         <th width="50%" align="center"><img src="image.png" width="80px" height="70px"></th>
      <th width="50%" align="center" style="color:royalblue;font-family:inherit ;font-size:30px" >Information sur le client</th>
     
   </tr>
   <tr>
      <th width="50%" height="30%" align="center">NON ET PRENOM</th>
      <th width="50%" height="30%" align="center">Nesrine Aouinti</th>
     
   </tr>
   <tr>
       <td style="font-family: sans-serif" align="center" valign="top">NUMERO DE CIN</td>
      <td align="center" valign="top">09881086</td>
      
   </tr>
   <tr>
      <td align="center" valign="top">DATE DE NAISSANCE</td>
      <td align="center" valign="top">06/01/1998</td>
   
   </tr>
   <tr>
      <td align="center" valign="top">EMAIL</td>
      <td align="center" valign="top">nesrineaouintii@gmail.com</td>
      
   </tr>
   <tr>
      <td align="center" valign="top">ADRESSE</td>
      <td align="center" valign="top">Nabeul-tunis</td>
   
   </tr>
   <tr>
      <td align="center" valign="top">TELEPHONE</td>
      <td align="center" valign="top">55731940</td>
      
   </tr>
   <tr>
      <td align="center" valign="top">POSTE</td>
      <td align="center" valign="top">Etudiante</td>
   
   </tr>
</table>
     </body>
 </html>