<?php


        function veriftoken($token,$conn){
       $sql = ("SELECT  * FROM users WHERE ((token='$token'))");
       $req = mysqli_query($conn,$sql) or die('Erreur SQL !'.$sql.''.mysqli_error($conn));
   
         $data = mysqli_fetch_array($req);
    
         
    
     
        if ($data !=null){
        return true ;
        
        }
            else{
                return false ;
            }
            
      
        }
        ?>
