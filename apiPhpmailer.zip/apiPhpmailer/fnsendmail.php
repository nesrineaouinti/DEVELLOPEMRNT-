
<?php
 
$msg=array();
  header('Content-Type: application/json');   
  include 'connectdb.php';

       require 'includes/PHPMailer.php';
        require 'includes/SMTP.php';
        require 'includes/Exception.php';  
        use PHPMailer\PHPMailer\PHPMailer;
        use PHPMailer\PHPMailer\SMTP;
       use PHPMailer\PHPMailer\Exception;    
  function sendmail($Host,$Port,$Username,$Password,$Subject,$mail2,$Body) {
        $mail= new  PHPMailer();
        $mail->CharSet = 'UTF-8';
        $mail->Charset='base64';
        $mail->IsHTML(true);
        $mail->isSMTP();
         $mail->Host =$Host;
         $mail-> SMTPAuth = "true";
         $mail-> SMTPSecure ="ssl";
         $mail->Port =$Port;
         $mail-> Username =$Username;
         $mail->Password =$Password;
         $mail-> Subject =$Subject;
         $mail->setFrom($Username);
          $mail->Body=embed_images($Body, $mail);
          $mail->addAddress($mail2);
          $mail->MsgHTML($Body);
          
         if(!$mail->send()) {
   
   $msg['message'] = 'mail non envoyer';

} else {
  $msg['message'] = 'mail est bien envoyer'; 
   
   
}
 $response = ['message' => $msg['message']];
echo json_encode($response);
         
         $mail->smtpClose();
         

  }







     
  

?>