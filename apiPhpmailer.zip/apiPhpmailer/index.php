 

      
 <?php
  $msg=array();
  header('Content-Type: application/json');
 
    require ('token.php');
         require ('fnsendmail.php');
        $headers = apache_request_headers();
       //var_dump($headers);
        $header= ['iduser'=>$headers['iduser']];
        //var_dump($header) ;
        $idu=json_encode($header);
          //echo $idu;
      
         $obj = json_decode($idu);
         $iduser = $obj->iduser;
          $sql = ("SELECT  Host,Port,Username,Password FROM usermail WHERE iduser='$iduser' ");
          $req = mysqli_query($conn,$sql) or die('Erreur SQL !'.$sql.''.mysqli_error($conn));
   
         $data = mysqli_fetch_array($req);
        // var_dump($data);
         
         
        $headers = apache_request_headers();
       //var_dump($headers);
        $header= ['token'=>$headers['token']];
        //var_dump($header) ;
        $toke=json_encode($header);
          //echo $toke;
      
         $obj = json_decode($toke);
         
        $Host=$data['Host'];
        
        $Port=$data['Port'];
        $Username=$data['Username'];
        $Password=$data['Password'];
        
        $Subject=$_GET['Subject'];
        $Body=$_GET['Body'];
        $mail2=$_GET['mail2'];
        
   
    
  
       $token = $obj->token;
       
  

          
         
function embed_images(&$body,$mailer){
    // get all img tags
    preg_match_all('/<img[^>]*src="([^"]*)"/i', $body, $matches);
    if (!isset($matches[0])) return;

    foreach ($matches[0] as $index=>$img)
    {
        // make cid
        $id = 'img'.$index;
        $src = $matches[1][$index];
        // now ?????
        $mailer->AddEmbeddedImage($src,$id);
        //this replace might be improved 
        //as it could potentially replace stuff you dont want to replace
        $body = str_replace($src,'cid:'.$id, $body);
    }
}


        
if (veriftoken($token,$conn)){
    
    
    sendmail($Host,$Port,$Username,$Password,$Subject,$mail2,$Body);

  
  
  } else {
  
  $msg['message'] = 'token non verified'; 
   $response = ['message' => $msg['message']];
echo json_encode($response);
        }    
 
         //$mail->smtpClose();
     
 
    
     ?>