   

<?php
         //On se connecte à la base de données
 $servername = "localhost";
$username = "root";
$password = "";
$dbname = "apiautho";
   
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
 die("Connection failed: " . $conn->connect_error); 
}


 ?>



  

    
   