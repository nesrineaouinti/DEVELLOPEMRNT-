<?php

  require 'connectdb.php';
require 'insert.php';
       
        $name=$_GET['name'];
        $login=$_GET['login'];
        $password=$_GET['password'];
        $token=$_GET['token'];
        
           
       createusers($name,$login,$password,$token) ;
                
                ?>