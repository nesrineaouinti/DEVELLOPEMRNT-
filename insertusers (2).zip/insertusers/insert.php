<?php 
include 'connectdb.php';
function createusers($name,$login,$password,$token) {
  
    $name ="name";
      $login="login";
      $password="password";
      $token="token";
      
     
        $sql= "INSERT INTO `users`(`name`, `login`,`password`, `token`) VALUES (:$name,:$login,:$password,:$token)";
  $res = $pdo->prepare($sql);
  $exec = $res->execute(array(":name"=>$name,":login"=>$login,":password"=>$password,":token"=>$token));
  // vérifier si la requête d'insertion a réussi
  if($exec){
    echo 'Données insérées';
  }else{
    echo "Échec de l'opération d'insertion";
  }
}
?>
    
    
    
    
    
    


   
