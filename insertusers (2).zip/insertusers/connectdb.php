
        <?php
     
   $host = 'localhost';
$dbname = 'apiautho';
$username = 'root';
$password = '';

  try {
  // se connecter à mysql
  $pdo = new pdo("mysql:host=$host;dbname=$dbname","$username","$password");
  } catch (PDOException $exc) {
    echo $exc->getMessage();
    exit();
}

  
    ?>
    
   