<?php
$resp = array();
 header('Content-Type: application/json');   
 

require 'connect.php';



//$id=$_GET['id'];
$name =$_GET['name'];
$login =$_GET['login'];
$password =$_GET['password'];
$token ="";

if(!empty($name)&& !empty($login)&& !empty($password)){
    
              
       $sql = "INSERT INTO users( name, login, password, token)"
        . " VALUES('$name','$login',md5('$password'),'$token')";
          
          
        

 
 if ($conn->query($sql) === TRUE)  {



      $resp['mesage'] = 'user insert';
 }     
           } else {
                 
            $resp['mesage'] = 'user nest pas inserer';
            }
            
    $sql ="SELECT id FROM users WHERE ( login='$login ' ) ";        
      $req = mysqli_query($conn,$sql) or die('Erreur SQL !'.$sql.''.mysqli_error($conn));
   
         $data = mysqli_fetch_array($req);
        // var_dump($data);
         $resp['id']= $data ['id'];
        
         
        //var_dump($data) ;

$conn->close();
$response = ['message' => $resp['mesage'],'id'=>$resp['id']];
echo json_encode($response);
           
?>