<?php
$resp = array();
 header('Content-Type: application/json');   
 
require 'connectdb.php';



//$id=$_GET['id'];
$Host =$_GET['Host'];
$Port =$_GET['Port'];
$Username =$_GET['Username'];
$Password =$_GET['Password'];

$headers = apache_request_headers();
       //var_dump($headers);
        $header= ['iduser'=>$headers['iduser']];
        //var_dump($header) ;
        $idu=json_encode($header);
          //echo $idu;
      
         $obj = json_decode($idu);
         $iduser = $obj->iduser;

//if(!empty($Host)&& !empty($Port)&& !empty($Username)&& !empty($Passsword)){
    


  $sql = "INSERT INTO usermail( iduser ,Host, Port, Username, Password)"
        . " VALUES('$iduser','$Host','$Port','$Username','$Password')";
         // $req = mysqli_query($conn,$sql) or die('Erreur SQL !'.$sql.''.mysqli_error($conn));
        


          if ($conn->query($sql) === TRUE) {
      
               $resp['mesage'] = 'configuration inserer';
              
          
    
           }else {
                 
            $resp['mesage'] = 'configuration nest pas inserer';
            }

    
            $conn->close();
     
$response = ['message' => $resp['mesage']];
echo json_encode($response);





?>