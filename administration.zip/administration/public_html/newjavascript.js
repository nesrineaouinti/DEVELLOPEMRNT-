var iduser="";

 $(document).ready(function(){
     $("#btn").click(function(){
         
          // e.preventDefault();
        $.ajax({
        
            url: 'http://localhost/apiInsertiondonnées/index.php',
            type: 'GET' ,
            async: true,
            typedata:'json',
            
            data:{
                name :$("#name").val(),
                login:$("#login").val(), // Nous récupérons la valeur de nos input que l'on fait passer à connexion.php
                password:$("#pwd").val(),
                 
            }
                      
            ,success: function(data)
         
              
            {   
             
                console.log(data.message);
              
                    if (data.message == "user nest pas inserer") {
                    
                    alert('Utilisateur  pas inserer verifier votre donnée');

                }
                else {
                    
                    
                 
                     $( "#id01" ). show ();
                     iduser=data.id ;
                     console.log(iduser);
                     
                     
                     
                      
                     $("#subm").click(function(){
         
        
           // e.preventDefault();
        $.ajax({
          headers :{
                iduser :iduser
          },

            url: 'http://localhost/insertconfig/index.php' ,
            type: 'GET' ,
            async: true,
            typedata:'json',
      
            data:{
                Host:$("#Host").val(), // Nous récupérons la valeur de nos input que l'on fait passer à connexion.php
                Port:$("#Port").val(),
                  Username:$("#Username").val(),
                 Password:$("#Password").val(),
              
                
            }
          
                      
            ,success: function(data)
            {
                if (data.message=="configuration inserer") {
                    alert('la config est bien inserer');
                }else {
                      alert('le config non inserer');
                }
                
                        console.log(data.message);
              
            
              
             
               
              
               
               } 
      
        
           
        
               
             
    

     });        
              
                   
     });   
                     
                     
                }
               
               
             console.log(data.message);
             
               
             
              
              
               
               } 
      
        
           
                
                
                
        
               
             
    

     
             
                   
     
 });
     });
 });
                     
                     
              
               
               
           
                 
                       // console.log(data.message);
              
            
              
             
               
              
               
               
                 
                 
              
                   
      
                     
                     
              
      
        
           
        
               
             
    

      
              
                   
   
                     
                     
                
               
               
            
             
               
               
         
              
              
               
               
      
        
           
        
               
             
    

         
              
                   
           
            
      
 



        
            
      
    

 
 
 